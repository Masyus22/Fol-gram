pkg install python bash git
pkg install python2
pkg install figlet
pkg install ruby
pkg install  bash
gem install lolcat
pkg install bastet &> //dev/null
pkg install vitetris &> //dev/null
pkg install nsnake &> //dev/null
pkg install moon-buggy &> //dev/null
pkg install ninvaders &> //dev/null
echo "Package Already Installed"
pip install requests colorama bs4
echo "pip Already Installed"
sleep 3
python ig.py
